{{/* Validate required fields */}}
{{- define "spog.requiredValues" -}}

  {{- $required := list
      "namespace"
      "mode"
      "images.prod.repository"
      "images.prod.tag"
      "images.prod.pullPolicy"
      "images.debug.repository"
      "images.debug.tag"
      "images.debug.pullPolicy"
      "deployment.replicas"
      "cluster_name"
      "spog_host_url"
      "spog_api_username"
      "spog_api_password"
      "cluster_master_ip_or_arn"
      "k8sinspect_integration_id"
      "enrichment_debug_mode"
      "scheduleInterval"
  }}

  {{- range $key := $required }}
    {{- $val := get .Values $key | default "" }}
    {{- if or (eq (printf "%v" $val | trim) "") (eq (printf "%v" $val | trim) "<no value>") }}
      {{- fail (printf "❌ Missing or empty value for required field: %s" $key) }}
    {{- end }}
  {{- end }}

{{- end }}

