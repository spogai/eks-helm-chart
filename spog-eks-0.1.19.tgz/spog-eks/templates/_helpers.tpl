{{/*
  Helper to enforce required values are provided
  Fails if a key is missing OR empty string
*/}}
{{- define "spog.requiredValues" -}}
{{- $required := list 
    "namespace"
    "mode"
    "images.prod.repository"
    "images.prod.tag"
    "images.prod.pullPolicy"
    "deployment.replicas"
    "cluster_name"
    "spog_host_url"
    "spog_api_username"
    "spog_api_password"
    "cluster_master_ip_or_arn"
    "k8sinspect_integration_id"
    "enrichment_debug_mode"
    "scheduleInterval"
-}}

{{- range $key := $required }}
  {{- $parts := splitList "." $key }}
  {{- $val := .Values }}
  {{- range $p := $parts }}
    {{- if hasKey $val $p }}
      {{- $val = index $val $p }}
    {{- else }}
      {{- fail (printf "❌ Missing required field: %s" $key) }}
    {{- end }}
  {{- end }}
  {{- if eq (printf "%v" $val) "" }}
    {{- fail (printf "❌ Missing or empty value for required field: %s" $key) }}
  {{- end }}
{{- end }}
{{- end }}

