{{- /*
Validate required values. This validator ensures all critical fields are set.
*/ -}}
{{- define "spog.requiredValues" -}}
{{- $required := list 
    "namespace"
    "mode"
    "deployment.replicas"
    "cluster_name"
    "spog_host_url"
    "spog_api_username"
    "spog_api_password"
    "cluster_master_ip_or_arn"
    "k8sinspect_integration_id"
    "enrichment_debug_mode"
    "mapperInterval"
    "scanInterval"
-}}
{{- range $key := $required }}
  {{- $parts := splitList "." $key }}
  {{- $val := $.Values }}
  {{- range $p := $parts }}
    {{- if hasKey $val $p }}
      {{- $val = index $val $p }}
    {{- else }}
      {{- fail (printf "❌ Missing required field: %s" $key) }}
    {{- end }}
  {{- end }}
  {{- if eq (printf "%v" $val) "" }}
    {{- fail (printf "❌ Missing or empty value for required field: %s" $key) }}
  {{- end }}
{{- end }}

{{- /* Additional check: mode must be prod or debug */ -}}
{{- $mode := .Values.mode | default "prod" -}}
{{- if and (ne $mode "prod") (ne $mode "debug") -}}
  {{- fail (printf "❌ Invalid mode '%s'. Allowed values: prod or debug" $mode) -}}
{{- end -}}
{{- end }}

